# Sécurité Massage Robotisé À Domicile

## Drapeaux Rouges

Refuser la séance robotisée et recommander un avis médical en cas de:

- Douleur aiguë, inexpliquée, intense, progressive, nocturne, ou après traumatisme.
- Fièvre, infection, inflammation importante, malaise, vertige, essoufflement.
- Engourdissement, perte de force, douleur irradiant bras/jambe, trouble neurologique.
- Suspicion de fracture, entorse grave, luxation, hernie discale aiguë non évaluée.
- Grossesse avec demande sur abdomen, lombaires fortes, points profonds, chaleur ou vibration.
- Cancer actif, thrombose, anticoagulants, troubles de coagulation, varices douloureuses.
- Chirurgie récente, cicatrice récente, plaie, brûlure, infection cutanée.
- Pacemaker, implant actif, cathéter, pompe, matériel médical dans la zone.
- Personne incapable de donner un consentement clair ou d'utiliser l'arrêt d'urgence.

## Questionnaire Minimal

Demander avant toute séance:

1. Quelle zone voulez-vous masser et pourquoi?
2. Douleur actuelle de 0 à 10?
3. Douleur récente après chute, effort violent ou accident?
4. Grossesse, chirurgie récente, maladie connue, anticoagulants, pacemaker ou implant?
5. Plaie, infection, bleu important, varices douloureuses, gonflement, chaleur locale?
6. Le bouton d'arrêt est-il accessible et la commande vocale "stop" fonctionne-t-elle?
7. La personne est-elle éveillée, sobre, capable de parler et de refuser à tout moment?

## Limites Opérationnelles

Configurer le robot pour:

- Démarrer à basse pression et basse vitesse.
- Limiter la durée de première séance à 5-10 minutes.
- Insérer une pause de feedback avant toute augmentation.
- Arrêter automatiquement si la personne dit: stop, arrête, douleur, malaise, vertige, engourdi, brûle, trop fort, peur.
- Arrêter si les capteurs détectent résistance anormale, force excessive, glissement non contrôlé, perte de contact, surchauffe, obstacle ou posture instable.
- Ne jamais verrouiller physiquement la personne.

## Zones Par Niveau De Prudence

| Zone | Statut | Notes |
|---|---|---|
| Trapèzes | autorisée avec prudence | éviter cou antérieur et pression profonde |
| Haut du dos | autorisée avec prudence | rester latéral à la colonne |
| Lombaires | très doux seulement | pas de pression profonde, pas si douleur aiguë |
| Jambes | autorisée avec prudence | refuser si gonflement, rougeur, douleur mollet |
| Pieds/mains | généralement doux | prudence diabète, neuropathie, plaies |
| Abdomen | éviter | sauf dispositif médicalement prévu |
| Cou antérieur/gorge | interdit | risque vasculaire et respiratoire |
| Colonne directe | interdit | ne pas appliquer d'appui mécanique direct |
| Visage | interdit par défaut | sauf robot conçu et validé pour visage |

## Sortie Sûre Pour Agent Robot

Inclure dans tout protocole:

- Objectif non médical.
- Consentement explicite.
- Drapeaux rouges vérifiés.
- Zones autorisées et interdites.
- Pression initiale, pression maximale, durée maximale.
- Pauses de feedback.
- Commandes d'arrêt.
- Conditions d'arrêt automatique.
- Journal d'incident.

## Formulation À Éviter

Ne pas promettre:

- Guérison, correction posturale, traitement d'une pathologie.
- Déblocage vertébral.
- Massage profond sans risque.
- Séance adaptée à une grossesse, une blessure ou une maladie sans avis médical.

Préférer:

- "Séance de détente non médicale."
- "Protocole prudent sous supervision."
- "Arrêt immédiat au moindre inconfort."
- "Avis médical requis si douleur ou condition particulière."
