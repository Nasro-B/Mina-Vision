---
name: massage-robot-domicile
description: Conception de séances, prompts, procédures et garde-fous pour un robot de massage à domicile. Utiliser quand l'utilisateur veut créer, régler, auditer ou automatiser un assistant/agent/robot qui masse une personne chez elle, choisir un protocole de massage non médical, définir des limites de pression/durée/zones, préparer un questionnaire de sécurité, ou écrire des instructions pour une session supervisée.
---

# Massage Robot Domicile

## Principe

Préparer des séances de massage robotisé prudentes, non médicales et supervisées. Ne jamais présenter le robot comme capable de diagnostiquer, traiter une pathologie, manipuler la colonne, corriger une blessure, ou remplacer un professionnel de santé.

Avant de produire une séquence exécutable, lire `references/securite.md`.

## Workflow

1. Identifier le contexte: objectif de la séance, âge approximatif, zone ciblée, durée souhaitée, niveau de douleur ou tension, antécédents pertinents, grossesse, chirurgie récente, traitement anticoagulant, troubles neurologiques, peau fragile, fièvre, infection, blessure, varices importantes, pacemaker ou implant médical.
2. Identifier les capacités réelles du robot: zones accessibles, actionneurs, plage de pression, vitesse, chaleur, vibration, capteurs de force, caméra, micro, bouton d'arrêt, contrôle vocal, journalisation, limite logicielle et limite matérielle.
3. Trier le risque:
   - Refuser la séance et recommander un avis médical si un drapeau rouge est présent.
   - Proposer une séance très légère si l'utilisateur est incertain mais sans drapeau rouge net.
   - Autoriser un protocole standard uniquement si consentement, supervision et arrêt d'urgence sont confirmés.
4. Choisir un protocole conservateur: détente générale, nuque/épaules douce, dos haut sans colonne, lombaires légères, jambes récupération douce, pieds mains, ou respiration-relaxation sans contact.
5. Définir les paramètres: durée courte, pression basse au départ, progression lente, zones interdites explicites, pause de feedback, critère d'arrêt immédiat.
6. Produire une sortie actionnable: briefing utilisateur, checklist robot, protocole minute par minute, limites, phrases vocales, et journal minimal.

## Règles De Sécurité

Toujours exiger un consentement explicite avant contact physique. Toujours prévoir une commande d'arrêt simple comme "stop", un bouton physique accessible, et un arrêt automatique si la personne dit douleur, vertige, engourdissement, malaise, brûlure, peur, ou "arrête".

Ne jamais masser directement:

- Colonne vertébrale, cou antérieur, gorge, abdomen profond, organes génitaux, poitrine, visage sauf dispositif validé pour cela.
- Plaie, bleu important, brûlure, infection cutanée, zone inflammée, fracture suspectée, articulation instable.
- Varices douloureuses ou saillantes, zone de thrombose suspectée, mollet douloureux et gonflé.
- Implant médical, pacemaker, cathéter, pompe, cicatrice récente, zone opérée sans accord médical.

Ne jamais utiliser chaleur ou vibration sans compatibilité matérielle confirmée et accord utilisateur.

## Paramètres Conservateurs

Utiliser ces bornes par défaut si le robot n'a pas de protocole fabricant plus strict:

| Paramètre | Débutant | Standard prudent | Maximum sans avis pro |
|---|---:|---:|---:|
| Durée totale | 5-8 min | 10-15 min | 20 min |
| Pression | 10-20% | 20-35% | 40% |
| Progression | +5% max | +5% par pause | jamais brusque |
| Pause feedback | toutes les 2 min | toutes les 3 min | obligatoire |
| Douleur tolérée | 0/10 | 0-2/10 | arrêter si >2/10 |

Si le robot mesure la force en newtons, ne convertir les pourcentages qu'avec la documentation fabricant. Ne pas inventer d'équivalence.

## Protocoles Types

### Détente Générale

Objectif: relaxation, stress, fatigue légère.

Séquence: respiration guidée 60 s, épaules trapèzes 3 min, dos haut paravertébral sans toucher la colonne 4 min, jambes légères 4 min, fin douce 60 s. Pression 20-30%, sans chaleur par défaut.

### Nuque Et Épaules Douces

Objectif: tension de bureau sans douleur aiguë.

Séquence: trapèzes 2 min par côté, épaules postérieures 2 min, haut du dos 4 min. Éviter cou antérieur, vertèbres cervicales et base du crâne si le robot n'est pas conçu pour cette zone.

### Jambes Récupération Douce

Objectif: fatigue musculaire simple.

Séquence: cuisses 3 min par côté, mollets 2 min par côté avec pression basse. Refuser si mollet gonflé, chaud, rouge, douloureux, ou risque thrombotique.

## Format De Sortie Recommandé

Répondre avec:

1. Statut: autorisé, à alléger, ou refusé.
2. Raison courte.
3. Checklist avant séance.
4. Protocole minute par minute.
5. Limites robot à configurer.
6. Phrases d'arrêt et de feedback.
7. Journal minimal: date, protocole, durée, zones, pression max, incidents, ressenti final.

## Exemples De Commandes Utilisateur

- "Crée une séance de massage robot pour épaules tendues après ordinateur."
- "Écris le prompt système d'un agent qui pilote un robot de massage à domicile."
- "Audite ce protocole de robot masseur et dis-moi ce qui est dangereux."
- "Prépare une checklist sécurité avant massage robotisé."

## Refus Type

Si la demande est risquée, refuser clairement la partie dangereuse et proposer une alternative sûre:

"Je ne peux pas valider un massage robotisé sur cette zone/situation. Risque: [raison]. Option sûre: séance sans contact, respiration guidée, ou massage uniquement sur zones non concernées après avis médical."
